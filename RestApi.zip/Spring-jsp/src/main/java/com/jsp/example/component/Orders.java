package com.jsp.example.component;

public class Orders {

}
