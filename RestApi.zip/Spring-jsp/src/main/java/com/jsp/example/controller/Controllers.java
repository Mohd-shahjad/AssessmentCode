package com.jsp.example.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.example.entity.Item;
import com.jsp.example.entity.Order;
import com.jsp.example.repository.ItemRepository;
import com.jsp.example.repository.OrderRepository;



@RestController
public class Controllers {

	@Autowired
	ItemRepository itemRepository;
	
	@Autowired
	OrderRepository orderRepository;
	
	@PostMapping("create-order")
	public Boolean createOrder(@RequestBody Order order) {
		Item item = null;
		if(order!=null) {
			Optional<Item> i = itemRepository.findById(order.getItem_id());
			 item = i.get();
			
		}
		Order or =orderRepository.save(order);
		if(or.getId()>0) {
			item.setOrderid(or.getId());
			itemRepository.save(item);
			return true;
		}
			
		return false;

	}

	@PostMapping("create-item")
	public boolean createItem(@RequestBody Item item) {
		Item it = itemRepository.save(item);
		if(it.getId()>0)
			return true;
		else
			return false;
		
	}
	@GetMapping("get-all-orderByOrderId")
	public Order getOrders(@RequestParam int orderId){
		System.out.println(orderId);
		Order order = null;
		List<Item> items = null;
		if(orderId>0) {
			Optional<Order> o = orderRepository.findById(orderId);
			order = o.get();
			 items = itemRepository.findItemsByorderid(orderId);
			order.setItem(items);
		}
		return order;
	}

}
